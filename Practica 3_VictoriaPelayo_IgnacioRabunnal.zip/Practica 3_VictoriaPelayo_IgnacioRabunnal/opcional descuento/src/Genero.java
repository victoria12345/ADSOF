/**
   * Enumeracion sobre los generos que puede ser una pelicula
   */
public enum Genero{
	COMEDIA, DRAMA, TERROR
}