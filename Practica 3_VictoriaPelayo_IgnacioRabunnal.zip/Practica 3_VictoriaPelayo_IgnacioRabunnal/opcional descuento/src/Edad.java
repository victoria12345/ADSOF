/**
* Enumeracion sobre los tipos de edades
* @author Victoria Pelayo e Ignacio Rabunnal
*/

public enum Edad{
	NINNO, ADULTO, JUBILADO, NINNO_R, ADULTO_R, JUBILADO_R
}