/**
* Enumeracion sobre los tipos de dia de la semana
* @author Victoria Pelayo e Ignacio Rabunnal
*/

public enum Dia{
	LUNES,MARTES,MIERCOLES,JUEVES,VIERNES,SABADO,DOMMINGO
}